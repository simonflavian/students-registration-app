<template>
  <div class="container">
    <h1>Register Student</h1>
    <form @submit.prevent="registerStudent">
      <label>Name:</label>
      <input v-model="student.name" type="text" required />

      <label>Email:</label>
      <input v-model="student.email" type="email" required />

      <label>Age:</label>
      <input v-model="student.age" type="number" required />

      <button type="submit">Register</button>
    </form>

    <p v-if="message">{{ message }}</p>
  </div>
</template>

<script>
import axios from 'axios';


export default {
  data() {
    return {
      student: {
        name: '',
        email: '',
        age: null
      },
      message: ''
    };
  },
  methods: {
    async registerStudent() {
      try {
        const response = await axios.post('http://localhost:3000/register', this.student);
        this.message = response.data.message;
        this.student = { name: '', email: '', age: null }; // reset form
      } catch (error) {
        this.message = 'Registration failed!';
        console.error(error);
      }
    }
  }
};
</script>

<style>
.container {
  max-width: 400px;
  margin: 50px auto;
  font-family: Arial;
}
form {
  display: flex;
  flex-direction: column;
}
label, input, button {
  margin-bottom: 15px;
}
button {
  padding: 10px;
}
</style>

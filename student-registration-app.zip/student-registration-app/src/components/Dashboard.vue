<template>
    <div>
      <h2>🎓 All Students</h2>
      <table border="1">
        <tr>
          <th>Name</th><th>Email</th><th>Age</th><th>Actions</th>
        </tr>
        <tr v-for="student in students" :key="student.id">
          <td><input v-model="student.name" /></td>
          <td><input v-model="student.email" /></td>
          <td><input v-model="student.age" /></td>
          <td>
            <button @click="updateStudent(student)">Update</button>
            <button @click="deleteStudent(student.id)">Delete</button>
          </td>
        </tr>
      </table>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        students: []
      };
    },
    methods: {
      async fetchStudents() {
        const res = await axios.get('http://localhost:3000/students');
        this.students = res.data;
      },
      async deleteStudent(id) {
        await axios.delete(`http://localhost:3000/students/${id}`);
        this.fetchStudents();
      },
      async updateStudent(student) {
        await axios.put(`http://localhost:3000/students/${student.id}`, {
          name: student.name,
          email: student.email,
          age: student.age
        });
        alert("Updated successfully!");
      }
    },
    mounted() {
      this.fetchStudents();
    }
  }
  </script>
  
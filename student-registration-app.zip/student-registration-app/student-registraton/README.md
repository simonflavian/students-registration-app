# student-registraton
 Just a simple form to register student by using Vue.js
